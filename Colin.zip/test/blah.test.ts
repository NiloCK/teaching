import { reunifyQuotes } from '../src';

describe('reunifyQuotes', () => {
  it('works', () => {
    expect(reunifyQuotes(['"this', 'is', 'combined"'])).toEqual([
      'this is combined',
    ]);

    expect(reunifyQuotes(['this', '"is"', 'not'])).toEqual([
      'this',
      'is',
      'not',
    ]);
  });
});
