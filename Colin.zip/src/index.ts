import fs from 'fs';

const inputFile = process.argv[2];
console.log(`Creating Filesystem from input: ${inputFile}`);

fs.readFile(inputFile, (err, data) => {
  if (err) {
    throw new Error(`Bad file read - ${inputFile} does not exist.`);
  }
  const commands: string[] = data
    .toString()
    .match(/[^\r\n]+/g) // pilfered from https://stackoverflow.com/questions/5034781/js-regex-to-split-by-line
    ?.map(l => l.valueOf())!;

  const fileSystem = new FS(commands);
  fileSystem.execute();
  console.log(fileSystem.toString());
});

type Command = 'mkdir' | 'create' | 'cp' | 'append' | 'rm' | 'cat';
function isCommand(c: string): c is Command {
  return (
    c === 'mkdir' ||
    c === 'create' ||
    c === 'cp' ||
    c === 'append' ||
    c === 'rm' ||
    c === 'cat'
  );
}

class FS {
  commands: string[] = [];
  root: Directory;

  mkdir(args: string[]): void {
    if (args.length !== 1) {
      throw new Error('mkdir requires ONE argument');
    }
    const path: string = args[0];

    if (this.exists(path)) {
      throw new Error(`mkdir: A file already exists at ${path}`);
    }

    const parentPath = this.getParentPath(path);
    const parentDir = this.getFile(parentPath);
    const newName = path.split('/').pop()!;

    if (isDirectory(parentDir)) {
      parentDir.children.push(new Directory(parentDir, newName));
    } else {
      throw new Error(`mkdir: parent dir of ${path} does not exist`);
    }
  }

  create(args: string[]): void {
    if (args.length !== 1) {
      throw new Error('create requires ONE argument');
    }
    const path: string = args[0];
    if (this.exists(path)) {
      throw new Error(`create: A file already exists at ${path}`);
    }
  }

  cp(args: string[]) {
    if (args.length !== 2) {
      throw new Error('cp requires TWO arguments');
    }
  }
  append(args: string[]) {
    if (args.length !== 2) {
      throw new Error('append requires TWO arguments');
    }

    const file = this.getFile(args[0]);
    if (isContentFile(file)) {
    }
  }
  rm(args: string[]) {
    if (args.length !== 1) {
      throw new Error('rm requires ONE argument');
    }
  }
  cat(args: string[]) {
    if (args.length !== 1) {
      throw new Error('cat requires ONE argument');
    }
  }

  toString(): string {
    return this.root.toString();
  }

  // private parsePath(
  //   path: string
  // ): {
  //   directoryPath: string;
  //   name: string;
  // } {
  //   const split = path.split('/');
  //   const name = split.pop()!;

  //   return {
  //     directoryPath: split.join('/'),
  //     name,
  //   };
  // }

  private getFile(path: string): File {
    if (this.exists(path)) {
      return this.root.getChild(path);
    } else {
      throw new Error(`File does not exist: ${path}`);
    }
  }

  private getParentPath(path: string): string {
    const split = path.split('/');
    split.pop();
    let ret = split.join('/');
    if (ret !== '') {
      return ret;
    } else {
      return '/';
    }
  }

  /**
   * Recursively search the file tree for a given path
   * @param path The path to check
   */
  private exists(path: string): boolean {
    return this.root.exists(path);
  }

  // private isContentFile(path: string): boolean {}
  // private isDirectory(path: string) {}

  constructor(commands: string[]) {
    this.commands = commands;
    this.root = new Directory(null, '');
  }

  /**
   * Main loop - attempts to run each command in sequence
   */
  public execute() {
    for (let i = 0; i < this.commands.length; i++) {
      try {
        this.executeCommand(this.commands[i]);
      } catch (e) {
        console.log(`ERROR: ${e}`);
      }
    }
  }

  private executeCommand(c: string) {
    let split = c.split(' ');
    split = reunifyQuotes(split);
    const openingArg = split[0];

    if (isCommand(openingArg)) {
      const command: Command = openingArg;
      const args = split.slice(1);
      // console.log(command);

      if (command === 'mkdir') {
        this.mkdir(args);
      } else if (command === 'create') {
        this.create(args);
      } else if (command === 'rm') {
      } else if (command === 'append') {
      } else if (command === 'cp') {
      } else if (command === 'cat') {
      }
    } else {
      throw new Error(`${openingArg} is not a valid Command!`);
    }
  }
}

class File {
  parent: Directory | null = null; // null here only for root
  name: string = ''; // empty string for root

  /**
   *
   */
  constructor(parent: Directory | null, name: string) {
    this.parent = parent;
    this.name = name;
  }

  public path(): string {
    if (this.parent === null) {
      return '/';
    }

    const ancestry: Directory[] = [];
    let previousGeneration: Directory | null = this.parent;

    while (previousGeneration !== null) {
      ancestry.push(previousGeneration);
      previousGeneration = previousGeneration.parent;
    }

    let ret: string = '';

    while (ancestry.length > 0) {
      const ancestor = ancestry.pop();
      ret += ancestor?.name + '/';
    }

    ret += this.name;

    return ret;
  }

  public move(dir: Directory, name: string) {
    if (this.parent === null) {
      throw new Error(`Cannot move the filesystem root!`);
    }
    const oldParent = this.parent;
    const oldName = this.name;

    // set new location
    this.parent = dir;
    this.name = name;

    // remove from privious location
    oldParent.children = oldParent.children.filter(c => c.name !== oldName);
  }
}

function isDirectory(f: File): f is Directory {
  return (f as Directory).children !== undefined;
}
class Directory extends File {
  public children: Array<File>;

  public toString(): string {
    return `${this.path()}
 ${this.children.map(c => c.toString())}`;
  }

  public getChild(path: string): File {
    if (this.path() === '/' && path === '/') {
      return this;
    }

    const split = path.split('/');

    if (split.length === 2) {
      // returning a child item
      const ret = this.children.find(child => {
        return child.name === split[1];
      });
      if (ret !== undefined) {
        return ret;
      } else {
        throw new Error(`Directory ${this.path()} failed to find file ${path}`);
      }
    } else {
      const childDir = this.children.find(c => {
        return c.name === split[0];
      })!;
      if (isDirectory(childDir)) {
        return childDir.getChild(split.slice(1).join('/'));
      } else {
        throw new Error(`Directory ${this.path()} failed to find file ${path}`);
      }
    }
  }

  public exists(path: string): boolean {
    if (this.path() === path) {
      return true;
    } else {
      return this.children.some(child => {
        if (isDirectory(child)) {
          return child.exists(path);
        } else {
          return child.path() === path;
        }
      });
    }
  }

  /**
   *
   */
  constructor(parent: Directory | null, name: string) {
    super(parent, name);
    this.children = [];
  }
}

function isContentFile(f: File): f is ContentFile {
  return (f as ContentFile).contents !== undefined;
}
class ContentFile extends File {
  contents: string = '';
  modification: number = 0;

  constructor(parent: Directory, name: string) {
    super(parent, name);
  }

  public append(text: string) {
    this.contents += text;
    this.modification++;
  }
}

/**
 * Recombine quote-wrapped input. IE, ['"hi', 'mom"'] -> ['hi mom']
 *
 * Required to undo damage to input after splitting arguments by a space
 *
 * @param split The split string to fix
 */
export function reunifyQuotes(split: string[]): string[] {
  for (let i = 0; i < split.length; i++) {
    if (split[i].startsWith('"')) {
      for (let j = i; j < split.length; j++) {
        if (split[j].endsWith('"')) {
          const left = split.slice(0, i);
          const right = split.slice(j + 1);

          //
          let middle = split.slice(i, j + 1).join(' ');
          middle = middle.substr(1, middle.length - 2); // remove quotes

          // recurse because this fcn only locates the first
          // instance to recombine
          return reunifyQuotes(left.concat([middle]).concat(right));
        }
      }
    }
  }

  return split;
}
