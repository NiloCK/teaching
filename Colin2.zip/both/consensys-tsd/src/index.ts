// import fs from 'fs';

// const inputFile = process.argv[2];
// console.log(`Creating Filesystem from input: ${inputFile}`);

// fs.readFile(inputFile, (err, data) => {
//   if (err) {
//     throw new Error(`Bad file read - ${inputFile} does not exist.`);
//   }
//   const commands: string[] = data
//     .toString()
//     .match(/[^\r\n]+/g) // pilfered from https://stackoverflow.com/questions/5034781/js-regex-to-split-by-line
//     ?.map(l => l.valueOf())!;

//   const fileSystem = new FS(commands);
//   fileSystem.execute();
//   console.log('\n' + fileSystem.toString());
// });

type Command =
  | 'mkdir'
  | 'create'
  | 'cp'
  | 'append'
  | 'rm'
  | 'cat'
  | 'pwd'
  | 'cd'
  | 'ls';
function isCommand(c: string): c is Command {
  return (
    c === 'mkdir' ||
    c === 'create' ||
    c === 'cp' ||
    c === 'append' ||
    c === 'rm' ||
    c === 'cat' ||
    c === 'pwd' ||
    c === 'cd' ||
    c === 'ls'
  );
}

export default class FS {
  commands: string[] = [];
  root: Directory;
  workingDirectory: Directory;
  public workingPath(): string {
    return this.workingDirectory.path();
  }

  mkdir(args: string[]): void {
    if (args.length !== 1) {
      throw new Error('mkdir requires ONE argument');
    }
    const path: string = args[0];

    if (this.exists(path)) {
      throw new Error(`mkdir: A file already exists at ${path}`);
    }

    const parentPath = this.getParentPath(path);
    const parentDir = this.getFile(parentPath);
    const newName = path.split('/').pop()!;

    if (isDirectory(parentDir)) {
      parentDir.addChild(new Directory(parentDir, newName));
    } else {
      throw new Error(`mkdir: parent dir of ${path} does not exist`);
    }
  }

  create(args: string[]): void {
    if (args.length !== 1) {
      throw new Error('create requires ONE argument');
    }
    const path = args[0];
    const parsedPath = this.parsePath(path);

    if (this.exists(path)) {
      throw new Error(`create: A file already exists at ${path}`);
    }

    const dir = this.getFile(parsedPath.directoryPath);
    if (isDirectory(dir)) {
      dir.addChild(new ContentFile(dir, parsedPath.name));
    }
  }

  cd(args: string[]) {
    if (args.length !== 1) {
      throw new Error(`cd requires ONE argument`);
    }
    const name = args[0];

    try {
      const subDir = this.workingDirectory.getChild(name);
      if (isDirectory(subDir)) {
        this.workingDirectory = subDir;
      }
    } catch (e) {
      throw new Error(`no such subdirectory`);
    }
  }
  pwd() {
    console.log(this.workingDirectory.path());
  }
  ls() {
    console.log(this.workingDirectory.ls());
  }

  cp(args: string[]) {
    if (args.length !== 2) {
      throw new Error('cp requires TWO arguments');
    }
    const src = args[0];
    const dest = args[1];
    // const parsedSrc = this.parsePath(src);
    const parsedDest = this.parsePath(dest);

    if (this.exists(src) && this.isWritable(dest)) {
      const f = this.getFile(src);
      const destDir = this.getFile(parsedDest.directoryPath);

      if (!isDirectory(destDir)) {
        throw new Error(`Destination path ${dest} is not a directory`);
      } else if (!isContentFile(f)) {
        throw new Error(`Target file ${src} is not a content file`);
      } else {
        destDir.addChild(f.clone(parsedDest.name));
      }
    } else {
      if (!this.exists(src)) {
        throw new Error(`Source file ${src} does not exist`);
      } else {
        throw new Error(`Destination path ${dest} is not writable`);
      }
    }
  }

  append(args: string[]) {
    if (args.length !== 2) {
      throw new Error('append requires TWO arguments');
    }

    if (!this.exists(args[1])) {
      throw new Error(`append: target file ${args[1]} does not exist`);
    }

    const file = this.getFile(args[1]);
    if (isContentFile(file)) {
      file.append(args[0]);
    }
  }

  rm(args: string[]) {
    if (args.length !== 1) {
      throw new Error('rm requires ONE argument');
    }
    const path = args[0];

    if (!this.exists(path)) {
      let message = `rm: target path ${path} does not exist`;
      if (
        path.endsWith('/') &&
        this.exists(path.substring(0, path.length - 1))
      ) {
        message += ` (did you mean "${path.substring(0, path.length - 1)}"?)`;
      }
      throw new Error(message);
    }

    this.getFile(path).rm();
  }

  cat(args: string[]) {
    if (args.length !== 1) {
      throw new Error('cat requires ONE argument');
    }
    const path = args[0];
    if (!this.exists(path)) {
      throw new Error(`cat: target file ${path} does not exits`);
    }
    const f = this.getFile(path);
    if (isDirectory(f)) {
      throw new Error(`cat: target path ${path} is a directory`);
    } else {
      if (isContentFile(f)) {
        console.log(f.contents);
      }
    }
  }

  toString(): string {
    return `FileSystem: \n${this.root.toString()}`;
  }

  private parsePath(
    path: string
  ): {
    directoryPath: string;
    name: string;
    type: 'relative' | 'absolute';
    upCount: number;
  } {
    const split = path.split('/');
    const name = split.pop()!;
    const type = split[0] === '' ? 'absolute' : 'relative';

    let upCount: number = 0;
    while (split[upCount] === '..') {
      upCount++;
    }

    return {
      directoryPath: split.join('/'),
      name,
      type: type,
      upCount,
    };
  }

  private getFile(path: string): File {
    if (path == '') {
      path = '/';
    }

    if (this.exists(path)) {
      return this.root.getChild(path);
    } else {
      throw new Error(`File does not exist: ${path}`);
    }
  }

  private getParentPath(path: string): string {
    const split = path.split('/');
    split.pop();
    let ret = split.join('/');
    if (ret !== '') {
      return ret;
    } else {
      return '/';
    }
  }

  /**
   * Recursively search the file tree for a given path
   * @param path The path to check
   */
  private exists(path: string): boolean {
    return this.root.exists(path);
  }

  /**
   * Returns whether a given path is eligible to be written to
   * @param path The path to check
   */
  private isWritable(path: string): boolean {
    if (this.exists(path)) {
      return false;
    }

    const parsed = this.parsePath(path);

    if (this.exists(parsed.directoryPath)) {
      const dir = this.getFile(parsed.directoryPath);
      return isDirectory(dir);
    } else {
      return false;
    }
  }

  // private isContentFile(path: string): boolean {}
  // private isDirectory(path: string) {}

  constructor(commands: string[]) {
    this.commands = commands;
    this.root = new Directory(null, '');
    this.workingDirectory = this.root;
  }

  /**
   * Main loop - attempts to run each command in sequence
   */
  public execute() {
    for (let i = 0; i < this.commands.length; i++) {
      try {
        console.log(this.commands[i]);
        this.executeCommand(this.commands[i]);
      } catch (e) {
        console.log(`ERROR: ${e.message}`);
      }
    }
  }

  public executeCommand(c: string) {
    let split = c.split(' ');
    split = reunifyQuotes(split);
    const openingArg = split[0];

    if (isCommand(openingArg)) {
      const command: Command = openingArg;
      const args = split.slice(1);
      // console.log(command);

      if (command === 'mkdir') {
        this.mkdir(args);
      } else if (command === 'create') {
        this.create(args);
      } else if (command === 'rm') {
        this.rm(args);
      } else if (command === 'append') {
        this.append(args);
      } else if (command === 'cp') {
        this.cp(args);
      } else if (command === 'cat') {
        this.cat(args);
      } else if (command === 'cd') {
        this.cd(args);
      } else if (command === 'pwd') {
        this.pwd();
      } else if (command === 'ls') {
        this.ls();
      }
    } else {
      throw new Error(`${openingArg} is not a valid Command!`);
    }
  }
}

abstract class File {
  parent: Directory | null = null; // null here only for root
  name: string = ''; // empty string for root

  /**
   *
   */
  constructor(parent: Directory | null, name: string) {
    this.parent = parent;
    this.name = name;
  }

  public path(): string {
    if (this.parent === null) {
      return '/';
    }

    const ancestry: Directory[] = [];
    let previousGeneration: Directory | null = this.parent;

    while (previousGeneration !== null) {
      ancestry.push(previousGeneration);
      previousGeneration = previousGeneration.parent;
    }

    let ret: string = '';

    while (ancestry.length > 0) {
      const ancestor = ancestry.pop();
      ret += ancestor?.name + '/';
    }

    ret += this.name;

    return ret;
  }

  public move(dir: Directory, name: string) {
    if (this.parent === null) {
      throw new Error(`Cannot move the filesystem root!`);
    }
    // remove oneself from previous parent
    this.parent.removeChild(this);

    // set new location
    this.parent = dir;
    this.name = name;
  }
  public rm(): void {
    if (this.parent === null) {
      throw new Error(`Cannot remove the filesystem root!`);
    }

    this.parent.removeChild(this);
  }
}

function isDirectory(f: File): f is Directory {
  return (f as Directory).addChild !== undefined;
}
class Directory extends File {
  private children: Array<File>;
  public addChild(f: File) {
    if (this.children.find(c => c.name === f.name) !== undefined) {
      throw new Error(
        `Directory ${this.path()} already contains a file named ${f.name}`
      );
    }

    this.children.push(f);
    f.parent = this;
  }
  public removeChild(f: File) {
    if (f.parent !== this) {
      throw new Error(
        `Failed attempt to remove non-child file ${f.name} from ${this.path()}.`
      );
    }

    this.children = this.children.filter(c => c.name !== f.name);
  }

  public ls(): string {
    let ret: string = `Contents of ${this.path()}:\n`;
    this.children.forEach(c => (ret += ' ' + c.name + '\n'));
    return ret;
  }
  public toString(): string {
    let ret = this.path() + '\n';

    this.children.forEach(c => {
      ret += c.toString();
    });

    return ret;
  }

  public getChild(path: string): File {
    if (this.path() === '/' && path === '/') {
      return this;
    }
    if (path === '..') {
      return this.parent || this;
    }

    const split = path.split('/');

    if (split.length === 2) {
      // returning a child item
      const ret = this.children.find(child => {
        return child.name === split[1];
      });
      if (ret !== undefined) {
        return ret;
      } else {
        throw new Error(`Directory ${this.path()} failed to find file ${path}`);
      }
    } else {
      const childDir = this.children.find(c => {
        return c.name === split[1];
      })!;
      if (isDirectory(childDir)) {
        return childDir.getChild(split.slice(1).join('/'));
      } else {
        return childDir;
        // throw new Error(`Directory ${this.path()} failed to find file ${path}`);
      }
    }
  }

  public exists(path: string): boolean {
    if (this.path() === path) {
      return true;
    } else {
      return this.children.some(child => {
        if (isDirectory(child)) {
          return child.exists(path);
        } else {
          return child.path() === path;
        }
      });
    }
  }

  /**
   *
   */
  constructor(parent: Directory | null, name: string) {
    super(parent, name);
    this.children = [];
  }
}

function isContentFile(f: File): f is ContentFile {
  return (f as ContentFile).contents !== undefined;
}
class ContentFile extends File {
  contents: string = '';
  modification: number = 0;

  constructor(parent: Directory, name: string) {
    super(parent, name);
  }

  public append(text: string) {
    this.contents += text;
    this.modification++;
  }

  public toString() {
    let ret = `${this.path()} (${this.modification})\n`;
    if (this.contents !== '') {
      ret += this.contents + '\n';
    }
    return ret;
  }

  public clone(newname?: string): ContentFile {
    const ret = new ContentFile(this.parent!, newname || this.name);
    ret.contents = this.contents;
    ret.modification = this.modification;
    return ret;
  }
}

/**
 * Recombine quote-wrapped input. IE, ['"hi', 'mom"'] -> ['hi mom']
 *
 * Required to undo damage to input after splitting arguments by a space
 *
 * @param split The split string to fix
 */
export function reunifyQuotes(split: string[]): string[] {
  for (let i = 0; i < split.length; i++) {
    if (split[i].startsWith('"')) {
      for (let j = i; j < split.length; j++) {
        if (split[j].endsWith('"')) {
          const left = split.slice(0, i);
          const right = split.slice(j + 1);

          //
          let middle = split.slice(i, j + 1).join(' ');
          middle = middle.substr(1, middle.length - 2); // remove quotes

          // recurse because this fcn only locates the first
          // instance to recombine
          return reunifyQuotes(left.concat([middle]).concat(right));
        }
      }
    }
  }

  return split;
}
