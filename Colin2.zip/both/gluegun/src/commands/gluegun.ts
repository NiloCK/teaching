import { GluegunCommand } from 'gluegun'
import FS from 'consensys-tsd'
// import FS from '../cli'

const fs = new FS([])

const command: GluegunCommand = {
  name: 'gluegun',
  run: async toolbox => {
    f(toolbox)
  }
}

const f = async function(toolbox, promptText = 'magmo://') {
  let { cmd } = await toolbox.prompt.ask([
    {
      type: 'input',
      name: 'cmd',
      message: promptText
    }
  ])

  if (cmd !== 'exit') {
    try {
      fs.executeCommand(cmd)
    } catch (e) {
      console.log(`Error: ${e.message}`)
    }
    f(toolbox, 'magmo:/' + fs.workingPath())
  }
}

module.exports = command
